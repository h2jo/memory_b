#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "c_memoryalloc.h"
#include "c_MersenneTwister.h"
#include "head_main.h"
